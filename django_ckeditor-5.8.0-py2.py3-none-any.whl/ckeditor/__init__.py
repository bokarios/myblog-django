VERSION = (5, 8, 0)
__version__ = '.'.join(map(str, VERSION))
